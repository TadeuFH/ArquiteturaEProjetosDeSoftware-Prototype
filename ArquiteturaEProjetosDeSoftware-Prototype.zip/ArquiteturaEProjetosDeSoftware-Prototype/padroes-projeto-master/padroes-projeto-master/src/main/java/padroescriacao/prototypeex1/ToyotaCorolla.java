package padroescriacao.prototypeex1;

public class ToyotaCorolla extends Vehicle {
    public ToyotaCorolla(int year) {
        super("Toyota", "Corolla", year);
    }

    public Vehicle clone() {
        return new ToyotaCorolla(this.year);
    }
}
