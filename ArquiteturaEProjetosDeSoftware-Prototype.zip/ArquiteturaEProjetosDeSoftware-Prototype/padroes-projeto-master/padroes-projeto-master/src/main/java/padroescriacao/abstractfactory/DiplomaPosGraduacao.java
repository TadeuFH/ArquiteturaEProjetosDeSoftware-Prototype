package padroescriacao.abstractfactory;

public class DiplomaPosGraduacao implements Diploma {

    public String emitir() {
        return "Diploma de Pós Graduação";
    }
}
