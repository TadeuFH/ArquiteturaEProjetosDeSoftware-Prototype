package padroescriacao.factorymethod;

public interface IServico {
    String executar();
    String cancelar();
}
