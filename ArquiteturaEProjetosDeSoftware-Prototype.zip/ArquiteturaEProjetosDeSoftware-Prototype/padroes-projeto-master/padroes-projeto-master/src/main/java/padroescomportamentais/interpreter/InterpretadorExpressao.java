package padroescomportamentais.interpreter;

public interface InterpretadorExpressao {

    public double interpretar();
}
