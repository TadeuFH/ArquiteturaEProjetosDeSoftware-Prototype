package padroesestruturais.adapter;

public class AvaliacaoNota {

    private float nota;

    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }
}
